package com.online.bakery.bean;


public interface DropdownListBean
{
	public String getKey();

	public String getValue();
}
